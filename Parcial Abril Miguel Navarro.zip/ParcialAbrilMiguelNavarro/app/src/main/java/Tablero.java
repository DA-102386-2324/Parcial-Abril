public class Tablero {
    private static final int FILAS = 3;
    private static final int COLUMNAS = 3;

    private boolean[][] lineasHorizontales;
    private boolean[][] lineasVerticales;
    private boolean[][] cuadradosCerrados;

    public Tablero() {
        lineasHorizontales = new boolean[FILAS][COLUMNAS - 1];
        lineasVerticales = new boolean[FILAS - 1][COLUMNAS];
        cuadradosCerrados = new boolean[FILAS - 1][COLUMNAS - 1];
    }

    public void dibujarLineaHorizontal(int fila, int columna) {
        if (fila < 0 || fila >= FILAS || columna < 0 || columna >= COLUMNAS - 1) {
            return;
        }
        lineasHorizontales[fila][columna] = true;
    }

    public void dibujarLineaVertical(int fila, int columna) {
        if (fila < 0 || fila >= FILAS - 1 || columna < 0 || columna >= COLUMNAS) {
            return;
        }
        lineasVerticales[fila][columna] = true;
    }

    public boolean[][] getLineasHorizontales() {
        return lineasHorizontales;
    }

    public boolean[][] getLineasVerticales() {
        return lineasVerticales;
    }

    public boolean[][] getCuadradosCerrados() {
        return cuadradosCerrados;
    }
}
