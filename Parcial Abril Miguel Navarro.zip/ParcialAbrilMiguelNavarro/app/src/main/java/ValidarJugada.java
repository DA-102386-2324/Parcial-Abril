public class ValidarJugada {
    public boolean validarJugada(int filaInicio, int columnaInicio, int filaFin, int columnaFin) {
        // Verificar si los puntos seleccionados son adyacentes horizontal o verticalmente
        if (!(filaInicio == filaFin && Math.abs(columnaInicio - columnaFin) == 1) &&
                !(columnaInicio == columnaFin && Math.abs(filaInicio - filaFin) == 1)) {
            mostrarToast("Los puntos seleccionados no son adyacentes horizontal o verticalmente");
            return false;
        }

        // Descartar la jugada si los puntos seleccionados están en una diagonal
        if (filaInicio != filaFin && columnaInicio != columnaFin) {
            mostrarToast("Los puntos seleccionados están en una diagonal");
            return false;
        }
        public static boolean hayLineaEntrePuntos(int filaInicio, int columnaInicio, int filaFin, int columnaFin)
        {
            // Comprobar si los puntos seleccionados están libres (no hay línea dibujada entre ellos)
            if (hayLineaEntrePuntos(filaInicio, columnaInicio, filaFin, columnaFin)) {
                mostrarToast("Ya hay una línea dibujada entre los puntos");
                return false;
            }
        }
        public static boolean LineaYaExistente(int filaInicio, int columnaInicio, int filaFin, int columnaFin)
        {
            // Asegurarse de que la línea que el jugador intenta dibujar no existe previamente y, por lo tanto, no es modificable
            if (LineaYaExistente(filaInicio, columnaInicio, filaFin, columnaFin)) {
                mostrarToast("La línea ya existe y no es modificable");
                return false;
            }
        }
        // La jugada es válida si cumple todos los criterios anteriores
        return true;
    }

    private boolean hayLineaEntrePuntos(int filaInicio, int columnaInicio, int filaFin, int columnaFin)
private boolean LineaYaExistente(int filaInicio, int collumnaInicio, int filaFin, int ColumnaFin)
    private void mostrarToast(String mensaje)
}
